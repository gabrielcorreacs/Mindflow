
// scripts/ui.js - utilitários simples de UI e mensagens
(function(){
  'use strict';
  function ensureToastContainer(){
    let c = document.getElementById('toast-container');
    if (!c){
      c = document.createElement('div');
      c.id = 'toast-container';
      c.setAttribute('aria-live', 'polite');
      c.setAttribute('aria-atomic', 'true');
      document.body.appendChild(c);
    }
    return c;
  }
  window.toast = function(msg, type='info', t=2200){
    const c = ensureToastContainer();
    const el = document.createElement('div');
    el.className = 'toast toast--'+type;
    el.role = 'alert';
    el.textContent = msg;
    c.appendChild(el);
    setTimeout(()=>{ el.classList.add('is-leaving'); setTimeout(()=>el.remove(), 400); }, t);
  };
  window.qs = (sel, ctx=document) => ctx.querySelector(sel);
  window.qsa = (sel, ctx=document) => Array.from(ctx.querySelectorAll(sel));
})();
