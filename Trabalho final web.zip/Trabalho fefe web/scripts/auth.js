// scripts/auth.js - autenticação simples (localStorage)
(function(){
  'use strict';

  window.Auth = {
    login(user, pass){
      const res = Store.login(user, pass);
      return !!res;
    },

    // registro
    // username = nome de usuário, email = e-mail, password = senha
    register(username, email, password){
      return Store.createUser(username, email, password);
    },

    logout(){
      Store.logout();
    },

    require(){
      if (!Store.isAuthed()){
        window.location.href = 'index.html';
      }
    }
  };
})();
