// camada de dados usando localStorage
(function(){
  'use strict';
  const KEY = 'torneios_store_v1';

  // Estado padrão do "banco" local
  const defaults = {
    schema: 1,
    users: [
      // Usuários iniciais (admin) para facilitar os primeiros acessos
      { id: 1, login: 'admin',          email: 'admin',          password: 'admin123', name: 'Administrador' },
      { id: 2, login: 'admin@demo.com', email: 'admin@demo.com', password: '123456',   name: 'Admin Demo' }
    ],
    tournaments: []
  };

  // Carrega os dados do localStorage ou usa o padrão
  function load(){
    const raw = localStorage.getItem(KEY);
    if (!raw) return JSON.parse(JSON.stringify(defaults));

    try {
      const data = JSON.parse(raw);

      const isInvalid =
        !data ||
        typeof data !== 'object' ||
        !Array.isArray(data.tournaments);

      if (isInvalid) throw new Error('invalid');

      // Junta o que veio salvo com o padrão (para futuras migrações de schema)
      return Object.assign({}, defaults, data);
    } catch(e){
      console.warn('Store corrompida, repondo padrão', e);
      return JSON.parse(JSON.stringify(defaults));
    }
  }

  // Salva o "banco" inteiro no localStorage
  function save(data){
    localStorage.setItem(KEY, JSON.stringify(data));
  }

  // Gera um id simples para usuários, times, torneios, etc.
  function generateId(){
    return Math.random().toString(36).slice(2) + Date.now().toString(36);
  }

  // Expondo a API de dados
  window.Store = {
    // Exporta todo o "banco"
    export(){
      return load();
    },

    // Importa um "banco" pronto (backup, por exemplo)
    import(obj){
      save(obj);
    },

    // Limpa apenas a store principal (não mexe em outras chaves)
    reset(){
      localStorage.removeItem(KEY);
    },

    // ============= AUTENTICAÇÃO =============

    // Faz login usando usuário OU e-mail + senha
    login(user, pass){
      const db = load();
      const input = String(user || '').trim().toLowerCase();

      const foundUser = db.users.find(u => {
        const login = String(u.login || '').toLowerCase();
        const email = String(u.email || '').toLowerCase();
        return (login === input || email === input) && u.password === pass;
      });

      if (!foundUser) return null;

      const token = generateId();

      localStorage.setItem('authToken', token);
      localStorage.setItem(
        'currentUser',
        JSON.stringify({
          id: foundUser.id,
          name: foundUser.name,
          login: foundUser.login,
          email: foundUser.email
        })
      );

      return { token };
    },

    // Retorna o usuário atualmente logado
    currentUser(){
      const raw = localStorage.getItem('currentUser');
      return raw ? JSON.parse(raw) : null;
    },

    // Diz se existe alguém autenticado
    isAuthed(){
      return !!localStorage.getItem('authToken');
    },

    // Faz logout sem apagar torneios
    logout(){
      localStorage.removeItem('authToken');
      localStorage.removeItem('currentUser');
    },

    // Cria um novo usuário (nome de usuário + e-mail + senha)
    createUser(username, email, password){
      const db = load();

      const trimmedUser  = String(username || '').trim();
      const trimmedEmail = String(email || '').trim();
      const trimmedPass  = String(password || '').trim();

      if (!trimmedUser || !trimmedEmail || !trimmedPass){
        return { ok: false, error: 'Preencha nome de usuário, e-mail e senha.' };
      }

      const userLower  = trimmedUser.toLowerCase();
      const emailLower = trimmedEmail.toLowerCase();

      const alreadyExists = db.users.some(u => {
        const login = String(u.login || '').toLowerCase();
        const mail  = String(u.email || '').toLowerCase();
        return (
          login === userLower  ||
          mail  === userLower  ||
          login === emailLower ||
          mail  === emailLower
        );
      });

      if (alreadyExists){
        return { ok: false, error: 'Já existe um usuário com esse nome de usuário ou e-mail.' };
      }

      const newUser = {
        id: generateId(),
        login: trimmedUser,
        email: trimmedEmail,
        password: trimmedPass,
        name: trimmedUser
      };

      db.users.push(newUser);
      save(db);

      return {
        ok: true,
        user: {
          id: newUser.id,
          login: newUser.login,
          email: newUser.email,
          name: newUser.name
        }
      };
    },

    // ============= TORNEIOS =============

    // Retorna todos os torneios cadastrados
    listTournaments(){
      const db = load();
      return db.tournaments;
    },

    // Cria um novo torneio
    createTournament({ name, prize }){
      const db = load();

      const tournament = {
        id: generateId(),
        name: String(name).trim(),
        prize: String(prize || ''),
        createdAt: new Date().toISOString(),
        teams: [],
        matches: []
      };

      db.tournaments.push(tournament);
      save(db);

      return tournament;
    },

    // Busca um torneio específico pelo id
    getTournament(id){
      const db = load();
      return db.tournaments.find(tournament => tournament.id === id) || null;
    },

    // Atualiza um torneio com base em um "patch"
    updateTournament(id, patch){
      const db = load();
      const index = db.tournaments.findIndex(tournament => tournament.id === id);
      if (index < 0) return null;

      db.tournaments[index] = { ...db.tournaments[index], ...patch };
      save(db);

      return db.tournaments[index];
    },

    // Remove um torneio por id
    deleteTournament(id){
      const db = load();
      db.tournaments = db.tournaments.filter(tournament => tournament.id !== id);
      save(db);
    },

    // ============= TIMES =============

    // Adiciona um time a um torneio
    addTeam(tournamentId, name, badge = null){
      const db = load();
      const tournament = db.tournaments.find(x => x.id === tournamentId);
      if (!tournament) return null;

      const cleanName = String(name || '').trim();
      if (!cleanName) throw new Error('Nome do time é obrigatório');

      const existsWithSameName = tournament.teams.some(team =>
        team.name.toLowerCase() === cleanName.toLowerCase()
      );
      if (existsWithSameName){
        throw new Error('Já existe um time com esse nome');
      }

      const team = {
        id: generateId(),
        name: cleanName,
        badge,
        players: [],
        stats: { yellow: 0, red: 0, fouls: 0 }
      };

      tournament.teams.push(team);
      save(db);
      return team;
    },

    // Atualiza os dados de um time
    updateTeam(tournamentId, teamId, patch){
      const db = load();
      const tournament = db.tournaments.find(x => x.id === tournamentId);
      if (!tournament) return null;

      const team = tournament.teams.find(x => x.id === teamId);
      if (!team) return null;

      Object.assign(team, patch);
      save(db);

      return team;
    },

    // Remove um time (e suas partidas) de um torneio
    removeTeam(tournamentId, teamId){
      const db = load();
      const tournament = db.tournaments.find(x => x.id === tournamentId);
      if (!tournament) return;

      tournament.teams = tournament.teams.filter(team => team.id !== teamId);
      tournament.matches = tournament.matches.filter(match =>
        match.homeId !== teamId && match.awayId !== teamId
      );

      save(db);
    },

    // Adiciona um jogador em um time
    addPlayer(tournamentId, teamId, playerName){
      const db = load();
      const tournament = db.tournaments.find(x => x.id === tournamentId);
      if (!tournament) return null;

      const team = tournament.teams.find(tm => tm.id === teamId);
      if (!team) return null;

      const cleanName = String(playerName || '').trim();
      if (!cleanName) throw new Error('Nome do jogador é obrigatório');

      const playerAlreadyExists = team.players.some(p =>
        p.name.toLowerCase() === cleanName.toLowerCase()
      );
      if (playerAlreadyExists){
        throw new Error('Jogador já existe no elenco');
      }

      const player = {
        id: generateId(),
        name: cleanName,
        goals: 0,
        assists: 0,
        yellow: 0,
        red: 0,
        fouls: 0
      };

      team.players.push(player);
      save(db);
      return player;
    },

    // Remove um jogador de um time
    removePlayer(tournamentId, teamId, playerId){
      const db = load();
      const tournament = db.tournaments.find(x => x.id === tournamentId);
      if (!tournament) return;

      const team = tournament.teams.find(tm => tm.id === teamId);
      if (!team) return;

      team.players = team.players.filter(p => p.id !== playerId);
      save(db);
    },

    // ============= PARTIDAS =============

    // Cria uma nova partida entre dois times
    createMatch(tournamentId, { date, homeId, awayId }){
      const db = load();
      const tournament = db.tournaments.find(x => x.id === tournamentId);
      if (!tournament) return null;

      if (homeId === awayId){
        throw new Error('Times da partida devem ser diferentes');
      }

      const match = {
        id: generateId(),
        date,
        homeId,
        awayId,
        events: [],
        status: 'scheduled',
        score: { home: 0, away: 0 }
      };

      tournament.matches.push(match);
      save(db);

      return match;
    },

    // Adiciona um evento (gol, cartão, falta, assistência) em uma partida
    addEvent(tournamentId, matchId, { type, teamId, playerId, minute = 0 }){
      const db = load();
      const tournament = db.tournaments.find(x => x.id === tournamentId);
      if (!tournament) return null;

      const match = tournament.matches.find(x => x.id === matchId);
      if (!match) return null;

      const event = {
        id: generateId(),
        type,
        teamId,
        playerId,
        minute: Number(minute) || 0
      };

      match.events.push(event);

      // Atualiza placar e estatísticas do jogador/time de acordo com o tipo
      if (type === 'goal'){
        if (match.homeId === teamId) match.score.home += 1;
        else if (match.awayId === teamId) match.score.away += 1;

        const team = tournament.teams.find(tm => tm.id === teamId);
        const player = team?.players.find(p => p.id === playerId);
        if (player) player.goals += 1;
      }

      if (type === 'assist'){
        const team = tournament.teams.find(tm => tm.id === teamId);
        const player = team?.players.find(p => p.id === playerId);
        if (player){
          player.assists = (player.assists || 0) + 1;
        }
      }

      if (type === 'yellow' || type === 'red' || type === 'foul'){
        const team = tournament.teams.find(tm => tm.id === teamId);

        if (type === 'yellow'){
          team.stats.yellow += 1;
          const player = team.players.find(p => p.id === playerId);
          if (player) player.yellow += 1;
        }

        if (type === 'red'){
          team.stats.red += 1;
          const player = team.players.find(p => p.id === playerId);
          if (player) player.red += 1;
        }

        if (type === 'foul'){
          team.stats.fouls += 1;
          const player = team.players.find(p => p.id === playerId);
          if (player) player.fouls += 1;
        }
      }

      save(db);
      return event;
    },

    // Marca uma partida como encerrada
    finishMatch(tournamentId, matchId){
      const db = load();
      const tournament = db.tournaments.find(x => x.id === tournamentId);
      if (!tournament) return null;

      const match = tournament.matches.find(x => x.id === matchId);
      if (!match) return null;

      match.status = 'played';
      save(db);

      return match;
    }
  };
})();
