// scripts/tournament.js - página do torneio: classificação, escudos, stats
(function(){
  'use strict';

  function qs(sel, ctx){ return (ctx||document).querySelector(sel); }
  function qsa(sel, ctx){ return Array.from((ctx||document).querySelectorAll(sel)); }

  function getId(){
    const p = new URLSearchParams(location.search);
    return p.get('id');
  }

  function renderTeamBadge(team){
    if (!team) return '';
    const firstLetter = (team.name || '?').trim().charAt(0).toUpperCase();
    if (team.badge){
      return `<span class="team-badge team-badge--img" style="background-image:url('${team.badge}')"></span>`;
    }
    return `<span class="team-badge">${firstLetter}</span>`;
  }

  function renderTeamLabel(team){
    if (!team) return '?';
    return `<span class="team-label">${renderTeamBadge(team)}<span class="team-label__name">${team.name}</span></span>`;
  }

  function computeStandings(t){
    const table = t.teams.map(team => ({
      teamId: team.id, name: team.name, pts:0, w:0,d:0,l:0, gf:0, ga:0, gd:0,
      fair: (team.stats.yellow*1 + team.stats.red*3 + team.stats.fouls*0.1)
    }));
    const idx = Object.fromEntries(table.map(r=>[r.teamId, r]));
    t.matches.filter(m=>m.status==='played').forEach(m=>{
      const home = idx[m.homeId], away = idx[m.awayId];
      if (!home || !away) return;
      home.gf += m.score.home; home.ga += m.score.away;
      away.gf += m.score.away; away.ga += m.score.home;
      if (m.score.home > m.score.away){ home.w++; away.l++; home.pts += 3; }
      else if (m.score.home < m.score.away){ away.w++; home.l++; away.pts += 3; }
      else { home.d++; away.d++; home.pts += 1; away.pts += 1; }
    });
    table.forEach(r=> r.gd = r.gf - r.ga);
    table.sort((a,b)=> b.pts - a.pts || b.gd - a.gd || b.gf - a.gf || a.fair - b.fair || a.name.localeCompare(b.name));
    return table;
  }

  function topScorersFromTopTeams(t, standings, topN=3){
    const topTeams = new Set(standings.slice(0, topN).map(r=>r.teamId));
    const rows = [];
    t.teams.forEach(team=>{
      if (!topTeams.has(team.id)) return;
      team.players.forEach(p=>{
        if (p.goals>0) rows.push({ playerName: p.name, teamName: team.name, goals: p.goals, teamId: team.id, playerId: p.id });
      });
    });
    rows.sort((a,b)=> b.goals - a.goals || a.playerName.localeCompare(b.playerName));
    return rows.slice(0, 10);
  }

  function renderHeader(t, standings){
    qs('#tName').textContent = t.name;
    qs('#tPrize').textContent = t.prize || '—';
    const total = t.matches.length;
    const played = t.matches.filter(m=>m.status==='played').length;
    qs('#tTotals').textContent = `${played} de ${total}`;
  }

  function renderStandings(t, table){
    const body = table.map(r=>{
      const team = t.teams.find(tm=>tm.id===r.teamId);
      return `<tr>
        <td>${renderTeamLabel(team)}</td>
        <td>${r.pts}</td><td>${r.w}</td><td>${r.d}</td><td>${r.l}</td>
        <td>${r.gf}</td><td>${r.ga}</td><td>${r.gd}</td><td>${r.fair.toFixed(1)}</td>
      </tr>`;
    }).join('');
    qs('#standings').innerHTML = `<table class="table">
      <thead><tr><th>Time</th><th>Pts</th><th>V</th><th>E</th><th>D</th><th>GF</th><th>GA</th><th>SD</th><th>Fair</th></tr></thead>
      <tbody>${body}</tbody>
    </table>`;
  }

  function computePlayerStats(t, playerId){
    const stats = {
      goals: 0,
      assists: 0,
      fouls: 0,
      yellow: 0,
      red: 0,
      perOpponent: {}
    };
    t.matches.forEach(m=>{
      if (m.status !== 'played') return;
      m.events.forEach(ev=>{
        if (ev.playerId !== playerId) return;
        const opponentId = ev.teamId === m.homeId ? m.awayId : m.homeId;
        const opponent = t.teams.find(tm=>tm.id === opponentId);
        const oppName = opponent ? opponent.name : 'Desconhecido';
        if (!stats.perOpponent[oppName]){
          stats.perOpponent[oppName] = { goals:0, assists:0, fouls:0, yellow:0, red:0 };
        }
        const bucket = stats.perOpponent[oppName];
        if (ev.type === 'goal'){ stats.goals++; bucket.goals++; }
        if (ev.type === 'assist'){ stats.assists++; bucket.assists++; }
        if (ev.type === 'foul'){ stats.fouls++; bucket.fouls++; }
        if (ev.type === 'yellow'){ stats.yellow++; bucket.yellow++; }
        if (ev.type === 'red'){ stats.red++; bucket.red++; }
      });
    });
    return stats;
  }

  function openPlayerStatsModal(tournamentId, playerId){
  const t = Store.getTournament(tournamentId);
  if (!t) return;

  let team = null, player = null;
  t.teams.forEach(tm => {
    const found = tm.players.find(p => p.id === playerId);
    if (found){ team = tm; player = found; }
  });
  if (!player) return;

  const stats = computePlayerStats(t, playerId);
  const opponents = Object.entries(stats.perOpponent);

  const opponentsRows = opponents.map(([name,s]) => `
    <tr>
      <td>${name}</td>
      <td>${s.goals}</td>
      <td>${s.assists}</td>
      <td>${s.fouls}</td>
      <td>${s.yellow}</td>
      <td>${s.red}</td>
    </tr>
  `).join('') || '<tr><td colspan="6" class="muted">Sem eventos registrados.</td></tr>';

  const html = `
    <div class="card">
      <h3>Estatísticas — ${player.name} <span class="muted">(${team.name})</span></h3>

      <div class="stats-grid">
        <!-- Coluna 1: totais -->
        <div class="card">
          <h4>Totais (por eventos)</h4>
          <p><strong>Gols:</strong> ${stats.goals}</p>
          <p><strong>Assistências:</strong> ${stats.assists}</p>
          <p><strong>Faltas:</strong> ${stats.fouls}</p>
          <p><strong>Amarelos:</strong> ${stats.yellow}</p>
          <p><strong>Vermelhos:</strong> ${stats.red}</p>
        </div>

        <!-- Coluna 2: tabela por adversário -->
        <div class="card">
          <h4>Por adversário</h4>
          <div style="overflow:auto; max-height:40vh; margin-top:.5rem;">
            <table class="table">
              <thead>
                <tr>
                  <th>Adversário</th>
                  <th>Gols</th>
                  <th>Assistências</th>
                  <th>Faltas</th>
                  <th>Amarelos</th>
                  <th>Vermelhos</th>
                </tr>
              </thead>
              <tbody>${opponentsRows}</tbody>
            </table>
          </div>
        </div>
      </div>

      <div style="margin-top:1rem; text-align:right;">
        <button class="btn btn--ghost" id="closeStats">Fechar</button>
      </div>
    </div>
  `;

  const modal = showModal(html);
  qs('#closeStats', modal).onclick = () => modal.remove();
}

  function renderScorers(t, list){
    if (!list.length){
      qs('#scorers').innerHTML = '<p class="muted">Sem gols registrados.</p>';
      return;
    }
    const items = list.map(s=>`<li>
      <button class="link link--player" data-team="${s.teamId}" data-player="${s.playerId}">
        ${s.playerName}
      </button>
      — ${s.teamName}
      <span class="badge">${s.goals} gol(s)</span>
    </li>`).join('');
    qs('#scorers').innerHTML = `<ul>${items}</ul>`;
    qsa('[data-player]', qs('#scorers')).forEach(btn=>{
      btn.onclick = ()=> openPlayerStatsModal(t.id, btn.dataset.player);
    });
  }

  function renderTeams(t){
    if (!t.teams.length){
      qs('#teamsBox').innerHTML = '<p class="muted">Nenhum time. Adicione no formulário ao lado.</p>';
      return;
    }
    const rows = t.teams.map(tm=>`
      <tr>
        <td>${renderTeamLabel(tm)}</td>
        <td>${tm.players.length}</td>
        <td>${tm.stats.fouls}</td>
        <td>${tm.stats.yellow}</td>
        <td>${tm.stats.red}</td>
        <td>
          <button class="btn btn--ghost" data-team="${tm.id}" data-act="players">Elenco</button>
          <button class="btn btn--ghost" data-team="${tm.id}" data-act="edit-badge">Escudo</button>
          <button class="btn btn--danger" data-team="${tm.id}" data-act="del">Remover</button>
        </td>
      </tr>`).join('');
    qs('#teamsBox').innerHTML = `<table class="table">
      <thead><tr><th>Time</th><th>Jogadores</th><th>Faltas</th><th>Amarelos</th><th>Vermelhos</th><th>Ações</th></tr></thead>
      <tbody>${rows}</tbody></table>`;

    qsa('[data-act="del"]', qs('#teamsBox')).forEach(b=> b.onclick = ()=>{
      if (!confirm('Remover time? Isso também remove as partidas deste time.')) return;
      Store.removeTeam(t.id, b.dataset.team);
      refresh();
    });
    qsa('[data-act="players"]', qs('#teamsBox')).forEach(b=> b.onclick = ()=> openPlayersModal(t.id, b.dataset.team));
    qsa('[data-act="edit-badge"]', qs('#teamsBox')).forEach(b=> b.onclick = ()=> openEditBadgeModal(t.id, b.dataset.team));
  }

  function openPlayersModal(tournamentId, teamId){
    const t = Store.getTournament(tournamentId);
    const team = t.teams.find(x=>x.id===teamId);
    const list = team.players.map(p=>`<tr>
      <td><button class="link link--player" data-stats="${p.id}">${p.name}</button></td>
      <td>${p.goals}</td><td>${p.fouls}</td><td>${p.yellow}</td><td>${p.red}</td>
      <td><button class="btn btn--danger" data-del="${p.id}">Remover</button></td>
    </tr>`).join('');
    const html = `<div class="card">
      <h3>Elenco — ${team.name}</h3>
      <form id="frmPlayer" class="grid grid-3" onsubmit="return false;">
        <div><label>Jogador</label><input id="plName" required></div>
        <div><label>&nbsp;</label><button class="btn" id="addPl">Adicionar</button></div>
      </form>
      <div style="overflow:auto; max-height:45vh">
        <table class="table">
          <thead><tr><th>Nome</th><th>Gols</th><th>Faltas</th><th>Amarelos</th><th>Vermelhos</th><th>Ações</th></tr></thead>
          <tbody id="plList">${list}</tbody>
        </table>
      </div>
      <div><button class="btn btn--ghost" id="closeModal">Fechar</button></div>
    </div>`;
    const modal = showModal(html);
    qs('#addPl', modal).onclick = ()=>{
      const name = qs('#plName', modal).value.trim();
      if (!name) return;
      try { Store.addPlayer(tournamentId, teamId, name); toast('Jogador adicionado','success'); } catch(e){ toast(e.message,'error'); }
      modal.remove();
      openPlayersModal(tournamentId, teamId);
    };
    qsa('[data-del]', modal).forEach(btn => btn.onclick = ()=>{
      Store.removePlayer(tournamentId, teamId, btn.dataset.del);
      btn.closest('tr').remove();
    });
    qsa('[data-stats]', modal).forEach(btn => btn.onclick = ()=>{
      openPlayerStatsModal(tournamentId, btn.dataset.stats);
    });
    qs('#closeModal', modal).onclick = ()=> modal.remove();
  }

  function renderMatches(t){
    if (!t.teams.length){
      qs('#matchesBox').innerHTML = '<p class="muted">Cadastre ao menos dois times para criar partidas.</p>';
      return;
    }
    const rows = t.matches.map(m=>{
      const homeTeam = t.teams.find(x=>x.id===m.homeId);
      const awayTeam = t.teams.find(x=>x.id===m.awayId);
      const status = m.status==='played' ? 'Encerrada' : 'Agendada';
      return `<tr>
        <td>${new Date(m.date).toLocaleString()}</td>
        <td>${renderTeamLabel(homeTeam)} x ${renderTeamLabel(awayTeam)}</td>
        <td>${m.score.home} - ${m.score.away}</td>
        <td>${status}</td>
        <td>
          <button class="btn" data-act="events" data-id="${m.id}">Eventos</button>
          <button class="btn btn--success" data-act="finish" data-id="${m.id}" ${m.status==='played'?'disabled':''}>Finalizar</button>
        </td>
      </tr>`;
    }).join('');
    qs('#matchesBox').innerHTML = `<table class="table">
      <thead><tr><th>Data</th><th>Partida</th><th>Placar</th><th>Status</th><th>Ações</th></tr></thead>
      <tbody>${rows}</tbody></table>`;

    qsa('[data-act="events"]', qs('#matchesBox')).forEach(b => b.onclick = ()=> openEventsModal(t.id, b.dataset.id));
    qsa('[data-act="finish"]', qs('#matchesBox')).forEach(b => b.onclick = ()=>{
      Store.finishMatch(t.id, b.dataset.id);
      toast('Partida encerrada.','success');
      refresh();
    });
  }

  function openEventsModal(tournamentId, matchId){
    const t = Store.getTournament(tournamentId);
    const m = t.matches.find(x=>x.id===matchId);
    const home = t.teams.find(x=>x.id===m.homeId);
    const away = t.teams.find(x=>x.id===m.awayId);
    const teamOpt = (tm)=> `<optgroup label="${tm.name}">` + tm.players.map(p=>`<option value="${tm.id}|${p.id}">${p.name}</option>`).join('') + '</optgroup>';
    const html = `<div class="card">
      <h3>Eventos — ${renderTeamLabel(home)} x ${renderTeamLabel(away)}</h3>
      <form id="frmEv" class="grid grid-3" onsubmit="return false;">
        <div>
          <label>Tipo</label>
          <select id="evType">
            <option value="goal">Gol</option>
            <option value="assist">Assistência</option>
            <option value="yellow">Cartão Amarelo</option>
            <option value="red">Cartão Vermelho</option>
            <option value="foul">Falta</option>
          </select>
        </div>
        <div>
          <label>Atleta</label>
          <select id="evTarget">
            ${teamOpt(home)}${teamOpt(away)}
          </select>
        </div>
        <div>
          <label>Minuto</label>
          <input id="evMin" type="number" value="0" min="0" max="130">
        </div>
        <div><label>&nbsp;</label><button class="btn" id="addEv">Adicionar</button></div>
      </form>
      <div style="overflow:auto; max-height:40vh">
        <table class="table">
          <thead><tr><th>Min</th><th>Tipo</th><th>Time</th><th>Jogador</th></tr></thead>
          <tbody id="evList"></tbody>
        </table>
      </div>
      <div><button class="btn btn--ghost" id="closeModal">Fechar</button></div>
    </div>`;
    const modal = showModal(html);
    function renderList(){
      const rows = m.events.map(ev=>{
        const tm = ev.teamId===home.id?home:away;
        const pl = tm.players.find(p=>p.id===ev.playerId)?.name || '?';
        const typeLabel = { goal:'Gol', assist:'Assistência', yellow:'Amarelo', red:'Vermelho', foul:'Falta' }[ev.type] || ev.type;
        return `<tr><td>${ev.minute}</td><td>${typeLabel}</td><td>${tm.name}</td><td>${pl}</td></tr>`;
      }).join('');
      qs('#evList', modal).innerHTML = rows || '<tr><td colspan="4" class="muted">Sem eventos</td></tr>';
    }
    renderList();
    qs('#addEv', modal).onclick = ()=>{
      const type = qs('#evType', modal).value;
      const value = qs('#evTarget', modal).value;
      const [teamId, playerId] = value.split('|');
      const minute = Number(qs('#evMin', modal).value)||0;
      Store.addEvent(tournamentId, matchId, { type, teamId, playerId, minute });
      toast('Evento adicionado', 'success');
      renderList();
    };
    qs('#closeModal', modal).onclick = ()=> modal.remove();
  }

  function openEditBadgeModal(tournamentId, teamId){
    const t = Store.getTournament(tournamentId);
    const team = t.teams.find(tm=>tm.id===teamId);
    if (!team) return;
    const html = `<div class="card">
      <h3>Escudo — ${team.name}</h3>
      <form id="frmBadge" class="grid grid-2" onsubmit="return false;">
        <div>
          <label>Escudo (URL)</label>
          <input id="badgeUrl" type="url" placeholder="https://..." value="${team.badge && team.badge.startsWith('http') ? team.badge : ''}">
        </div>
        <div>
          <label>Escudo (arquivo)</label>
          <input id="badgeFile" type="file" accept="image/*">
        </div>
      </form>
      <div style="margin-top:1rem; display:flex; align-items:center; gap:.75rem;">
        ${renderTeamBadge(team)}
        <span class="muted">Pré-visualização</span>
      </div>
      <div style="margin-top:1rem; display:flex; justify-content:space-between; gap:.5rem;">
        <button class="btn btn--danger" id="btnRemove">Remover escudo</button>
        <div style="flex:1; text-align:right;">
          <button class="btn btn--ghost" id="btnClose">Cancelar</button>
          <button class="btn" id="btnSave">Salvar</button>
        </div>
      </div>
    </div>`;
    const modal = showModal(html);
    const urlInput = qs('#badgeUrl', modal);
    const fileInput = qs('#badgeFile', modal);
    const previewBadge = qs('.team-badge', modal);

    function setPreviewFromUrl(){
      const url = urlInput.value.trim();
      if (!url){
        previewBadge.style.backgroundImage = '';
        previewBadge.textContent = (team.name || '?').charAt(0).toUpperCase();
        return;
      }
      previewBadge.style.backgroundImage = 'url('+url+')';
      previewBadge.textContent = '';
    }

    urlInput.addEventListener('input', setPreviewFromUrl);
    fileInput.addEventListener('change', ()=>{
      if (!fileInput.files.length){ setPreviewFromUrl(); return; }
      const file = fileInput.files[0];
      const reader = new FileReader();
      reader.onload = e=>{
        previewBadge.style.backgroundImage = 'url('+e.target.result+')';
        previewBadge.textContent = '';
      };
      reader.readAsDataURL(file);
    });

    qs('#btnRemove', modal).onclick = ()=>{
      Store.updateTeam(tournamentId, teamId, { badge:null });
      toast('Escudo removido','success');
      modal.remove();
      refresh();
    };

    qs('#btnSave', modal).onclick = ()=>{
      const urlVal = urlInput.value.trim();
      const file = fileInput.files[0];
      if (file){
        const reader = new FileReader();
        reader.onload = e=>{
          Store.updateTeam(tournamentId, teamId, { badge: e.target.result });
          toast('Escudo atualizado','success');
          modal.remove();
          refresh();
        };
        reader.readAsDataURL(file);
      } else {
        Store.updateTeam(tournamentId, teamId, { badge: urlVal || null });
        toast('Escudo atualizado','success');
        modal.remove();
        refresh();
      }
    };

    qs('#btnClose', modal).onclick = ()=> modal.remove();
  }

  function showModal(innerHtml){
    const bg = document.createElement('div');
    Object.assign(bg.style, { position:'fixed', inset:'0', background:'rgba(0,0,0,.6)', display:'grid', placeItems:'center', zIndex:'999' });
    const box = document.createElement('div');
    box.innerHTML = innerHtml;
    box.style.maxWidth = '900px';
    box.style.width = '95%';
    bg.appendChild(box);
    document.body.appendChild(bg);
    bg.addEventListener('click', (e)=>{ if (e.target===bg) bg.remove(); });
    return bg;
  }

  function bindForms(t){
    const frmTeam = qs('#frmTeam');
    if (frmTeam){
      frmTeam.onsubmit = (e)=>{
        e.preventDefault();
        try{
          const name = qs('#teamName').value.trim();
          const url = qs('#teamBadge')?.value.trim() || '';
          const fileInput = qs('#teamBadgeFile');
          const submit = ()=>{
            const badge = submit.badgeValue;
            Store.addTeam(t.id, name, badge || null);
            qs('#teamName').value = '';
            if (qs('#teamBadge')) qs('#teamBadge').value = '';
            if (fileInput) fileInput.value = '';
            const previewCircle = qs('#badgePreviewCircle');
            if (previewCircle){
              previewCircle.style.backgroundImage = '';
              previewCircle.textContent = '?';
              previewCircle.style.display = 'none';
            }
            toast('Time adicionado','success');
            refresh();
          };
          if (fileInput && fileInput.files.length){
            const file = fileInput.files[0];
            const reader = new FileReader();
            reader.onload = e2=>{
              submit.badgeValue = e2.target.result;
              submit();
            };
            reader.readAsDataURL(file);
          } else {
            submit.badgeValue = url;
            submit();
          }
        }catch(err){
          toast(String(err.message||err),'error');
        }
      };
    }

    const frmMatch = qs('#frmMatch');
    if (frmMatch){
      frmMatch.onsubmit = (e)=>{
        e.preventDefault();
        try{
          const date = qs('#mDate').value;
          const homeId = qs('#mHome').value;
          const awayId = qs('#mAway').value;
          Store.createMatch(t.id, { date, homeId, awayId });
          toast('Partida criada','success');
          refresh();
        }catch(err){
          toast(String(err.message||err),'error');
        }
      };
    }
  }

  function populateMatchSelectors(t){
    const opts = t.teams.map(tm=>`<option value="${tm.id}">${tm.name}</option>`).join('');
    qs('#mHome').innerHTML = opts;
    qs('#mAway').innerHTML = opts;
  }

  function refresh(){
    const id = getId();
    const t = Store.getTournament(id);
    if (!t){ location.href='dashboard.html'; return; }
    const standings = computeStandings(t);
    renderHeader(t, standings);
    renderStandings(t, standings);
    renderScorers(t, topScorersFromTopTeams(t, standings));
    renderTeams(t);
    renderMatches(t);
    populateMatchSelectors(t);
    bindForms(t);
  }

  document.addEventListener('DOMContentLoaded', function(){
    if (window.Auth && Auth.require) Auth.require();
    qs('#btnLogout')?.addEventListener('click', ()=>{ Auth.logout(); location.href='index.html'; });
    refresh();
  });
})();