
(function(){
  'use strict';

  function makeSortable(table){
    const ths = table.tHead ? Array.from(table.tHead.rows[0].cells) : [];
    const getCellVal = (tr, idx) => tr.cells[idx] ? tr.cells[idx].innerText.trim() : "";
    ths.forEach((th, idx)=>{
      th.style.cursor = 'pointer';
      th.setAttribute('title','Clique para ordenar');
      th.addEventListener('click', ()=>{
        const tbody = table.tBodies[0];
        const rows = Array.from(tbody.rows);
        const current = th.dataset.sort || 'none';
        const next = current === 'asc' ? 'desc' : 'asc';
        ths.forEach(h=>h.dataset.sort='none');
        th.dataset.sort = next;
        const collator = new Intl.Collator('pt-BR', {numeric:true, sensitivity:'base'});
        rows.sort((a,b)=>{
          const va = getCellVal(a, idx);
          const vb = getCellVal(b, idx);
          const cmp = collator.compare(va, vb);
          return next === 'asc' ? cmp : -cmp;
        });
        rows.forEach(r=>tbody.appendChild(r));
      });
    });
  }

  function makeFilterable(table, input){
    if(!input) return;
    input.addEventListener('input', ()=>{
      const q = input.value.toLowerCase();
      const tbody = table.tBodies[0];
      Array.from(tbody.rows).forEach(tr=>{
        const text = tr.innerText.toLowerCase();
        tr.style.display = text.includes(q) ? '' : 'none';
      });
    });
  }

  function makePaginable(table, select){
    if(!select) return;
    const tbody = table.tBodies[0];
    function render(){
      const size = parseInt(select.value,10);
      let visibleCount = 0;
      Array.from(tbody.rows).forEach(tr=>{
        const isFilteredOut = tr.style.display === 'none';
        if(isFilteredOut){ tr.style.visibility = ''; return; }
        visibleCount++;
        tr.style.visibility = (size>0 && visibleCount>size) ? 'hidden' : '';
      });
    }
    select.addEventListener('change', render);
    const obs = new MutationObserver(render);
    obs.observe(tbody, {childList:true, subtree:false});
    render();
  }

  function makeColumnToggles(table, container){
    if(!container || !table.tHead) return;
    const ths = Array.from(table.tHead.rows[0].cells);
    container.innerHTML = '';
    ths.forEach((th, idx)=>{
      const lbl = document.createElement('label');
      lbl.style.marginRight = '10px';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = true;
      cb.addEventListener('change', ()=>{
        const show = cb.checked ? '' : 'none';
        // toggle header
        th.style.display = show;
        // toggle all column cells
        Array.from(table.tBodies[0].rows).forEach(tr=>{
          if(tr.cells[idx]) tr.cells[idx].style.display = show;
        });
      });
      lbl.appendChild(cb);
      lbl.appendChild(document.createTextNode(' ' + (th.innerText || 'Col '+(idx+1))));
      container.appendChild(lbl);
    });
  }

  window.DataEnhancer = { makeSortable, makeFilterable, makePaginable, makeColumnToggles };
})();
