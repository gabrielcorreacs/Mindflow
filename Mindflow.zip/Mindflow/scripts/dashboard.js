
// scripts/dashboard.js - home após login: torneios ativos, prêmios, criação
(function(){
  'use strict';
  function renderList(){
    const wrap = qs('#tournamentsList');
    const list = Store.listTournaments();
    if (!list.length){
      wrap.innerHTML = '<p class="muted">Nenhum torneio criado ainda. Crie o primeiro usando o formulário ao lado.</p>';
      return;
    }
    const rows = list.map(t=>{
      const total = t.matches.length;
      const played = t.matches.filter(m=>m.status==='played').length;
      return `<tr>
        <td><a href="tournament.html?id=${t.id}">${t.name}</a></td>
        <td>${t.prize||'-'}</td>
        <td>${t.teams.length}</td>
        <td>${played}/${total}</td>
        <td>${new Date(t.createdAt).toLocaleDateString()}</td>
      </tr>`;
    }).join('');
    wrap.innerHTML = `<table class="table">
      <thead><tr><th>Torneio</th><th>Premiação</th><th>Times</th><th>Jogos (feitos/total)</th><th>Criado em</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
  }

  function renderPrizes(){
    const box = qs('#prizesBox');
    const list = Store.listTournaments();
    const items = list.filter(t=>t.prize).map(t=>`<li>${t.name}: <strong>${t.prize}</strong></li>`).join('');
    box.innerHTML = items ? `<ul>${items}</ul>` : '<p class="muted">Sem premiações registradas.</p>';
  }

  function onCreate(e){
    e.preventDefault();
    const name = qs('#tnName').value.trim();
    const prize = qs('#tnPrize').value.trim();
    if (!name){ toast('Dê um nome ao torneio.', 'error'); return; }
    const t = Store.createTournament({ name, prize });
    toast('Torneio criado com sucesso.', 'success');
    qs('#tnName').value = ''; qs('#tnPrize').value = '';
    renderList(); renderPrizes();
    // link rápido
    qs('#quickLink').innerHTML = `<a class="btn btn--success" href="tournament.html?id=${t.id}">Abrir ${t.name}</a>`;
  }

  document.addEventListener('DOMContentLoaded', function(){
    Auth.require();
    // navbar actions
    qs('#btnLogout')?.addEventListener('click', ()=>{ Auth.logout(); location.href='index.html'; });
    renderList();
    renderPrizes();
    qs('#createForm').addEventListener('submit', onCreate);
    const tbd=qs("#tblDash"); if(window.DataEnhancer&&tbd){ DataEnhancer.makeSortable(tbd);}
  });
})();
